document.getElementById("yes-btn").addEventListener("click", function() {
    document.getElementById("response").innerHTML = "😍 Yay! You made me the happiest person alive! 💖💍";
});

document.getElementById("no-btn").addEventListener("mouseover", function() {
    this.style.top = Math.random() * window.innerHeight + "px";
    this.style.left = Math.random() * window.innerWidth + "px";
});
